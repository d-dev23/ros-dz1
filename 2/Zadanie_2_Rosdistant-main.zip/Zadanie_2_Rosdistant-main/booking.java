import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class YourServletName extends HttpServlet {
    // Override the doPost method to handle POST requests
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the session
        HttpSession session = request.getSession();

        // Retrieve the session attributes
        String tno1 = (String) session.getAttribute("tno");
        String tname1 = (String) session.getAttribute("tname");
        String source1 = (String) session.getAttribute("s1");
        String destination1 = (String) session.getAttribute("d1");
        String date1 = (String) session.getAttribute("date1");
        String class1 = (String) session.getAttribute("c1");
        String nosa1 = (String) session.getAttribute("nosa");
        int nosa2 = Integer.parseInt(nosa1);

        System.out.println(tno1 + " " + tname1 + " " + source1 + " " + destination1 + " " + date1 + " " + class1 + " " + nosa1);
        int j;
        for (j = 1; j <= 6; j++) {
            String n = request.getParameter("name" + j);
            String a = request.getParameter("age" + j);
            String g = request.getParameter("gender" + j);
            String b = request.getParameter("berth" + j);
            String s = request.getParameter("senior" + j);
            String ad = request.getParameter("aadhaar" + j);
            System.out.println(n + " " + a + " " + g + " " + b + " " + s + " " + ad);

            if (n != null && !n.isEmpty() && nosa2 > 0) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/train_reservation",
                            "root", "maan");
                    Statement st = con.createStatement();
                    st.executeUpdate("INSERT INTO bookinfo(train_no, train_name, source, destination, date, class, name, age, gender, berth, senior, aadhaar) VALUES ('" + tno1 + "','" + tname1 + "','" + source1 + "','" + destination1 + "','" + date1 + "','" + class1 + "','" + n + "','" + a + "','" + g + "','" + b + "','" + s + "','" + ad + "')");

                    st.executeUpdate("UPDATE traininfo SET no_of_seat_available = no_of_seat_available - 1 WHERE train_no = '" + tno1 + "' AND class = '" + class1 + "'");
                    nosa2 = nosa2 - 1;
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        if (j == 7) {
            response.sendRedirect("booked.jsp");
        } else {
            response.sendRedirect("book.jsp");
        }
    }
}

